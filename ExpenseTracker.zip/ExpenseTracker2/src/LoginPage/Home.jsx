import React from "react";
import './styles.css';

const Home = ({ onStartTracking }) => {
  return (
    <div style={styles.container}>
      <div style={styles.overlay}>
        <h2 className="typing-heading">Keep Track of Your Income and Expenses</h2>
        <p style={styles.text}>
        Track, Save, Succeed! Take charge of your finances effortlessly. Monitor income, control expenses, and achieve your goals with our easy-to-use Expense Tracker. Every penny counts!🌟
        </p>
        
        <button style={styles.button} onClick={onStartTracking}>
          Get Started
        </button>
      </div>
    </div>
  );
};

const styles = {
  container: {
    position: "relative",
    width: "100vw",
    height: "100vh",
    backgroundImage:
      "url('https://t3.ftcdn.net/jpg/02/06/14/56/360_F_206145642_ch7d799Dq38xZfRQjEAYRLaYS9jsmezF.jpg')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  overlay: {
    marginTop: "2%",
    marginLeft: "20%",
    backgroundColor: "transparent",
    padding: "40px",
    borderRadius: "15px",
    textAlign: "center",
    maxWidth: "600px",
  },
  text: {
    fontSize: "18px",
    color: "white",
    marginBottom: "20px",
  },
  button: {
    width:"250px",
    padding: "12px 20px",
    fontSize: "16px",
    cursor: "pointer",
    background: "crimson",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    transition: "background 0.3s, transform 0.3s",
  },
};

export default Home;
