import React from "react";
import styles from "./Navbar.module.css"
const Navbar = ({ onButtonClick }) => {
  return (
    <nav className={styles.nav}>
      <div className={styles.left}>
        <img
          src="https://img.icons8.com/?size=160&id=A7N2wkPKoVQw&format=png"
          alt="Logo"
          className={styles.logo}
        />
        <h1 className={styles.title}>ExpenseTracker</h1>
      </div>
      <div className={styles.right}>
        <button className={styles.button} onClick={() => onButtonClick("signup")}>
          SignUp
        </button>
        <button className={styles.button} onClick={() => onButtonClick("signin")}>
          SignOut
        </button>
      </div>
    </nav>
  );
};


export default Navbar;
