import React, { useState } from "react";
import Navbar from "./LoginPage/Navbar.jsx";
import Home from "./LoginPage/Home.jsx";
import Forms from "./LoginPage/Forms.jsx";
import LoginPage from "./LoginPage/Login.jsx";
import ExpenseTracker from "./Features/ExpenseTracker.jsx";

const App = () => {
  const [formType, setFormType] = useState("");
  const [page, setPage] = useState("home");
  const [userName, setUserName] = useState("");

  const handleOpenForm = (type) => {
    setFormType(type);
  };

  const handleSuccess = (nextPage, loggedInUserName) => {
    setFormType("");
    if (loggedInUserName) {
      setUserName(loggedInUserName); // Update userName on successful login
    }
    if (nextPage === "expensetracker") {
      setPage("expensetracker");
    } else {
      setFormType(nextPage);
    }
  };

  return (
    <div>
      <Navbar onButtonClick={handleOpenForm} />
      {page === "home" && !formType && (
        <Home onStartTracking={() => handleOpenForm("login")} />
      )}
      {formType && (
        <Forms
          formType={formType}
          onClose={() => setFormType("")}
          onSuccess={(nextPage, loggedInUserName) =>
            handleSuccess(nextPage, loggedInUserName)
          }
        />
      )}
      {page === "expensetracker" && <ExpenseTracker userName={userName} />}
    </div>
  );
};

export default App;
